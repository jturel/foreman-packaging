## rules.xml
Rules in `rules.xml` are intended to find a proper processes. Rules defines path in processes tree from that one, which was affected by update through parents to the process, what user knows and what actually should be restarted.

## applications.xml
Definitions in `applications.xml` have nothing to do with searching. They are used just before application is printed to the output. They can set one of several types to the application (they can be printed differently) or define specific way, how to restart the application.
